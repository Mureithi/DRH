 <div id="dialog-form" title="Change Password">
 <p class="validateTips">All fields are required.</p>
 
    <form>
    <fieldset>
        <label for="name">Current Password</label>
        <input type="password"  id="oldpassword" name="oldpassword""  placeholder="Old Password" class="text ui-widget-content ui-corner-all">
        <label for="email">New Password</label>
        <input type="password"  id="newpassword" name="newpassword"  placeholder="New Password" class="text ui-widget-content ui-corner-all">
        <label for="password">Confirm Password</label>
        <input type="password" name="password" id="password" placeholder="Confirm Password" class="text ui-widget-content ui-corner-all" />
    </fieldset>
    </form>
    </div>